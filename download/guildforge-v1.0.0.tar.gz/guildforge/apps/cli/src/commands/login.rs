//! `guildforge login` — store the Discord bot token.
//!
//! Phase 6: writes to `~/.config/guildforge/token` with mode 0600.
//! Phase 7+: with `--features keychain`, uses the OS keychain via the
//! `keyring` crate (macOS Keychain, Windows Credential Manager, Linux
//! Secret Service).

use std::io::{self, Read, Write};
use std::path::PathBuf;
use std::process::ExitCode;

/// The service name used for keychain entries.
#[cfg_attr(not(feature = "keychain"), allow(dead_code))]
const KEYCHAIN_SERVICE: &str = "guildforge";
/// The account name used for keychain entries.
#[cfg_attr(not(feature = "keychain"), allow(dead_code))]
const KEYCHAIN_ACCOUNT: &str = "bot-token";

/// Path to the token file (used when keychain feature is not enabled).
fn token_file_path() -> PathBuf {
    if let Ok(p) = std::env::var("GUILDFORGE_TOKEN_FILE") {
        return PathBuf::from(p);
    }
    let home = std::env::var("HOME").unwrap_or_else(|_| ".".to_string());
    PathBuf::from(home)
        .join(".config")
        .join("guildforge")
        .join("token")
}

/// Store the token. Uses keychain if the feature is enabled,
/// otherwise falls back to file-based storage.
fn store_token(token: &str) -> Result<String, String> {
    #[cfg(feature = "keychain")]
    {
        match keyring::Entry::new(KEYCHAIN_SERVICE, KEYCHAIN_ACCOUNT) {
            Ok(entry) => {
                entry.set_password(token).map_err(|e| e.to_string())?;
                return Ok("OS keychain".to_string());
            }
            Err(e) => {
                // Keychain not available; fall back to file.
                eprintln!(
                    "guildforge: keychain not available ({}), falling back to file",
                    e
                );
            }
        }
    }
    // File-based storage.
    let dest = token_file_path();
    if let Some(parent) = dest.parent() {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    std::fs::write(&dest, token).map_err(|e| e.to_string())?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        if let Ok(meta) = std::fs::metadata(&dest) {
            let mut perms = meta.permissions();
            perms.set_mode(0o600);
            let _ = std::fs::set_permissions(&dest, perms);
        }
    }
    Ok(dest.display().to_string())
}

/// Delete the token from keychain or file.
#[cfg_attr(not(feature = "keychain"), allow(dead_code))]
fn delete_token() -> Result<(), String> {
    #[cfg(feature = "keychain")]
    {
        if let Ok(entry) = keyring::Entry::new(KEYCHAIN_SERVICE, KEYCHAIN_ACCOUNT) {
            let _ = entry.delete_credential();
        }
    }
    let dest = token_file_path();
    if dest.exists() {
        std::fs::remove_file(&dest).map_err(|e| e.to_string())?;
    }
    Ok(())
}

/// Run the `login` command.
pub fn run(token_file: Option<&std::path::Path>) -> ExitCode {
    // Determine the token source.
    let token = if let Some(path) = token_file {
        match std::fs::read_to_string(path) {
            Ok(t) => t.trim().to_string(),
            Err(e) => {
                eprintln!(
                    "guildforge: could not read token file {}: {e}",
                    path.display()
                );
                return ExitCode::from(2);
            }
        }
    } else if !atty::is(atty::Stream::Stdin) {
        let mut buf = String::new();
        if io::stdin().read_to_string(&mut buf).is_err() {
            eprintln!("guildforge: could not read token from stdin");
            return ExitCode::from(2);
        }
        buf.trim().to_string()
    } else {
        eprint!("Enter Discord bot token: ");
        let _ = io::stderr().flush();
        let token = rpassword::read_password().unwrap_or_default();
        token.trim().to_string()
    };

    if token.is_empty() {
        eprintln!("guildforge: token is empty");
        return ExitCode::from(2);
    }

    if token.len() < 50 {
        eprintln!(
            "guildforge: token looks too short (expected 50+ chars, got {})",
            token.len()
        );
        return ExitCode::from(2);
    }

    match store_token(&token) {
        Ok(location) => {
            eprintln!("Token saved to {location}");
            eprintln!("Run `guildforge validate examples/company.yaml` to test.");
            ExitCode::SUCCESS
        }
        Err(e) => {
            eprintln!("guildforge: could not save token: {e}");
            ExitCode::from(2)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn token_file_path_respects_env() {
        std::env::set_var("GUILDFORGE_TOKEN_FILE", "/tmp/custom-token");
        assert_eq!(token_file_path(), PathBuf::from("/tmp/custom-token"));
        std::env::remove_var("GUILDFORGE_TOKEN_FILE");
    }

    #[test]
    fn token_file_path_defaults_to_home() {
        let saved = std::env::var("GUILDFORGE_TOKEN_FILE").ok();
        std::env::remove_var("GUILDFORGE_TOKEN_FILE");
        let p = token_file_path();
        assert!(p.ends_with("token"));
        assert!(p.to_string_lossy().contains("guildforge"));
        if let Some(v) = saved {
            std::env::set_var("GUILDFORGE_TOKEN_FILE", v);
        }
    }
}
