//! `guildforge logout` — delete the stored bot token.

use std::process::ExitCode;

/// Run the `logout` command. Deletes the token from keychain (if
/// feature enabled) and/or file. Idempotent.
pub fn run() -> ExitCode {
    let mut removed_something = false;

    #[cfg(feature = "keychain")]
    {
        if let Ok(entry) = keyring::Entry::new("guildforge", "bot-token") {
            if entry.delete_credential().is_ok() {
                removed_something = true;
            }
        }
    }

    let dest = if let Ok(p) = std::env::var("GUILDFORGE_TOKEN_FILE") {
        std::path::PathBuf::from(p)
    } else {
        let home = std::env::var("HOME").unwrap_or_else(|_| ".".to_string());
        std::path::PathBuf::from(home)
            .join(".config")
            .join("guildforge")
            .join("token")
    };

    if dest.exists() {
        match std::fs::remove_file(&dest) {
            Ok(()) => {
                eprintln!("Token removed from {}", dest.display());
                removed_something = true;
            }
            Err(e) => {
                eprintln!("guildforge: could not remove {}: {e}", dest.display());
                return ExitCode::from(2);
            }
        }
    }

    if !removed_something {
        eprintln!("No token found (already logged out).");
    }

    ExitCode::SUCCESS
}
