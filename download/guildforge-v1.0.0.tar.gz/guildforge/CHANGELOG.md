# Changelog

All notable user-facing changes to GuildForge are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html)
once `v0.1.0` is tagged.

## [1.0.0] — 2026-07-03

### Added — Full v1.0 release

- **All 15 CLI commands implemented**: `init`, `validate`, `plan`,
  `apply`, `destroy`, `diff`, `import`, `export`, `doctor`, `backup`,
  `restore`, `login`, `logout`, `version`, `completions`.
- **Declarative YAML schema v1** with 12 top-level keys covering
  server, roles, categories, channels, permissions, overwrites,
  webhooks, invites, forum tags, welcome screen, server guide, and
  ordering.
- **Provider architecture** with async `Provider` trait. Discord is the
  first implementation; Slack/Teams/Mattermost are planned.
- **Discord provider** with full CRUD for roles, categories, channels
  (text/voice/forum/announcement/stage), permission overwrites,
  webhooks, invites, forum tags, welcome screen, and server guide.
  Rate-limit middleware with per-route and global buckets. Retry with
  exponential backoff. Idempotent operations.
- **SQLite state store** with file locking, transactions, migrations,
  and audit log. State is the source of truth for plan diffs.
- **Deterministic planner** — the same `(config, state)` pair always
  produces a byte-identical plan. Topological ordering. Content-hash
  diffing. Tainted-resource handling (delete + recreate).
- **Executor** with retry, partial-failure handling (taint and
  continue), cancellation support, and idempotent state commits.
- **Import** reads live Discord via `provider.list()` and emits YAML.
- **Export** dumps state to canonical YAML with stable ordering.
- **Diff** shows structural differences between two config files.
- **Doctor** detects bidirectional drift (state↔live).
- **Backup/restore** snapshots the SQLite state file.
- **Next.js 16 dashboard** with YAML editor, plan viewer, SSE-streamed
  apply logs, history view, and encrypted token storage. 14 API
  routes. Shells out to the CLI per ADR-0008.
- **Shell completions** for bash, zsh, fish, powershell, and elvish.
- **OS keychain integration** (`--features keychain`) for secure token
  storage on macOS, Windows, and Linux (Secret Service).
- **Cross-compilation release CI** building 5 targets: x86_64-linux,
  aarch64-linux, x86_64-macos, aarch64-macos, x86_64-windows.
- **8 ADRs** documenting every cross-cutting architectural decision.
- **259 tests** across 11 Rust crates + CLI integration tests + E2E
  pipeline tests.
- **mdbook documentation site** with installation, quick start,
  configuration, CLI reference, YAML schema, and architecture guides.
- **Homebrew formula** and **scoop manifest** for package management.

### Known Limitations

- AutoMod rule CRUD unsupported (Discord API limitation). See
  [`docs/DISCORD_LIMITATIONS.md`](./docs/DISCORD_LIMITATIONS.md).
- Server guide (onboarding) full prompt editing is partial — Discord's
  PATCH endpoint requires the full onboarding object.
- Custom-emoji role icons and forum tags not supported in v1.
- Emoji/sticker management deferred to a future phase.
- Thread creation not managed (threads are message-derived).

### Security

- Bot token stored encrypted (file-based AES-256-GCM with mode 0600, or
  OS keychain with `--features keychain`).
- Token never appears in CLI args, logs, plan output, or state files.
- Token never sent to the browser in the dashboard.
- See [`docs/SECURITY.md`](./docs/SECURITY.md) for the full threat model.
