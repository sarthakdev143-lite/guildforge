# GuildForge

> Infrastructure as Code for Discord Workspaces.

[![CI](https://github.com/your-org/guildforge/actions/workflows/ci.yml/badge.svg)](https://github.com/your-org/guildforge/actions/workflows/ci.yml)
[![Release](https://github.com/your-org/guildforge/actions/workflows/release.yml/badge.svg)](https://github.com/your-org/guildforge/actions/workflows/release.yml)
[![License: MIT OR Apache-2.0](https://img.shields.io/badge/license-MIT%2FApache--2.0-blue.svg)](./LICENSE-MIT)
[![Rust](https://img.shields.io/badge/rust-1.88%2B-orange.svg)](./rust-toolchain.toml)
[![Tests](https://img.shields.io/badge/tests-286-green.svg)](#testing)
[![Binary Size](https://img.shields.io/badge/binary-7.6%20MB-blue.svg)](#performance)

`GuildForge` lets you deploy an entire Discord workspace — server config, roles,
categories, channels, permissions, forum tags, webhooks, ordering — from a single
declarative YAML file, exactly the way Terraform deploys cloud infrastructure.

```bash
guildforge apply company.yaml
```

That one command creates (or reconciles) every role, category, channel, permission
overwrite, and webhook described in `company.yaml`. Run it again and GuildForge
computes a minimal diff and applies only what changed. Run `guildforge destroy`
and the workspace is torn back down — cleanly, idempotently, with a full audit
trail in local SQLite state.

---

## Quick Start

```bash
# Install
cargo install --path apps/cli

# Authenticate
guildforge login

# Scaffold a config
guildforge init --template company

# Validate
guildforge validate guildforge.yaml

# Preview changes
guildforge plan guildforge.yaml

# Apply
guildforge apply --auto-approve guildforge.yaml

# Check for drift
guildforge doctor

# Tear down
guildforge destroy --auto-approve guildforge.yaml
```

---

## Features

| Feature | Status |
|---|---|
| 15 CLI commands | ✅ |
| YAML schema v1 (12 top-level keys) | ✅ |
| Discord provider (full CRUD + rate limiting) | ✅ |
| SQLite state store with file locking | ✅ |
| Deterministic planner (byte-stable plans) | ✅ |
| Executor (retry, taint, cancel, idempotent) | ✅ |
| Import / Export / Diff / Doctor | ✅ |
| Backup / Restore | ✅ |
| Next.js 16 dashboard (14 routes) | ✅ |
| Shell completions (5 shells) | ✅ |
| OS keychain support (`--features keychain`) | ✅ |
| Cross-compilation CI (5 targets) | ✅ |
| 286 tests (unit + integration + E2E + fuzz + property) | ✅ |
| Performance: 500-channel plan in 245 µs | ✅ |
| Man pages (`clap_mangen`) | ✅ |

## CLI Commands

| Command | Description |
|---|---|
| `init` | Scaffold `guildforge.yaml` from template |
| `validate` | Parse + validate config |
| `plan` | Compute + print execution plan |
| `apply` | Apply config (`--auto-approve` for CI) |
| `destroy` | Destroy all resources in config |
| `diff` | Structural diff between two configs |
| `import` | Read live Discord → YAML |
| `export` | State → YAML |
| `doctor` | Drift detection (state ↔ live) |
| `backup` | Snapshot state file |
| `restore` | Restore state from backup |
| `login` | Store bot token (file or OS keychain) |
| `logout` | Delete stored token |
| `version` | Print version info |
| `completions` | Generate shell completions |

## Installation

### From source

```bash
cargo install --path apps/cli
```

### From GitHub Releases

Download the appropriate archive from the
[Releases page](https://github.com/your-org/guildforge/releases):

| Platform | Archive |
|---|---|
| Linux x86_64 | `guildforge-v1.0.0-x86_64-unknown-linux-gnu.tar.gz` |
| Linux ARM64 | `guildforge-v1.0.0-aarch64-unknown-linux-gnu.tar.gz` |
| macOS x86_64 | `guildforge-v1.0.0-x86_64-apple-darwin.tar.gz` |
| macOS ARM64 | `guildforge-v1.0.0-aarch64-apple-darwin.tar.gz` |
| Windows x86_64 | `guildforge-v1.0.0-x86_64-pc-windows-msvc.zip` |

### Homebrew (macOS)

```bash
brew tap your-org/guildforge
brew install guildforge
```

### Scoop (Windows)

```bash
scoop bucket add guildforge https://github.com/your-org/guildforge
scoop install guildforge
```

### Shell completions

```bash
guildforge completions bash > /etc/bash_completion.d/guildforge
guildforge completions zsh > "${fpath[1]}/_guildforge"
guildforge completions fish > ~/.config/fish/completions/guildforge.fish
```

---

## Architecture

```
            ┌──────────┐     ┌──────────┐     ┌──────────┐
 YAML ───▶  │ parser   │ ──▶ │validation│ ──▶ │ planner  │
            └──────────┘     └──────────┘     └────┬─────┘
                                                   │
                                                   ▼
            ┌──────────┐     ┌──────────┐     ┌──────────┐
  state ◀── │ executor │ ◀── │  engine  │ ◀── │   plan   │
            └────┬─────┘     └──────────┘     └──────────┘
                 │
                 ▼
            ┌──────────────────┐
            │ provider trait   │
            └────────┬─────────┘
                     │
        ┌────────────┼────────────┐
        ▼            ▼            ▼
   ┌─────────┐ ┌──────────┐ ┌──────────┐
   │ Discord │ │  Slack   │ │ Teams    │   (future)
   └─────────┘ └──────────┘ └──────────┘
```

Discord is **never** accessed directly from the engine. Every external system is
reached through the `Provider` trait defined in `crates/provider`. See
[`ARCHITECTURE.md`](./ARCHITECTURE.md) for the full living architecture document and
[`docs/adr/`](./docs/adr/) for the 8 Architecture Decision Records.

## Testing

GuildForge has 286 tests across 5 categories:

| Category | Count | Description |
|---|---|---|
| Unit tests | ~200 | Per-function, in-file |
| Integration tests | ~50 | Cross-crate, in-process |
| Property-based | ~24 | `proptest` fuzzing + determinism |
| Mock-HTTP | 14 | `wiremock` Discord API tests |
| E2E pipeline | 3 | Full validate→plan→apply→doctor→export→destroy |
| Conformance | 10 | Provider trait contract verification |

Performance benchmarks (via `criterion`):

| Benchmark | Time |
|---|---|
| 500-channel guild plan | 245 µs |
| 600-resource plan | 265 µs |
| 250-resource all-noop plan | 730 µs |

---

## Documentation

| Document | Purpose |
|---|---|
| [ARCHITECTURE.md](./ARCHITECTURE.md) | Living architecture overview |
| [docs/SCHEMA.md](./docs/SCHEMA.md) | YAML schema specification (v1) |
| [docs/CLI_REFERENCE.md](./docs/CLI_REFERENCE.md) | Every CLI command, flags, exit codes |
| [docs/CRATE_LAYOUT.md](./docs/CRATE_LAYOUT.md) | Per-crate responsibilities & dependency rules |
| [docs/TESTING.md](./docs/TESTING.md) | Testing strategy, coverage targets, fixtures |
| [docs/SECURITY.md](./docs/SECURITY.md) | Token handling, threat model, disclosure |
| [docs/DISCORD_LIMITATIONS.md](./docs/DISCORD_LIMITATIONS.md) | Unsupported Discord features |
| [docs/adr/](./docs/adr/) | 8 Architecture Decision Records |
| [ROADMAP.md](./ROADMAP.md) | Milestones, 0 → 1.0 → 2.0 |
| [DEVELOPMENT.md](./DEVELOPMENT.md) | Development setup guide |
| [docs-site/](./docs-site/) | mdbook documentation site |

## Tech Stack

| Layer | Choice |
|---|---|
| Language | Rust (edition 2021) |
| Async runtime | Tokio |
| HTTP | Reqwest + rustls |
| Serialization | Serde + serde_yaml |
| CLI | Clap v4 + clap_complete + clap_mangen |
| Errors | Anyhow + ThisError |
| Database | SQLite via SQLx |
| Logging | tracing |
| Dashboard | Next.js 16, Tailwind CSS 4 |
| CI | GitHub Actions (7 jobs) |

## License

Dual-licensed under MIT OR Apache-2.0. See [`LICENSE-MIT`](./LICENSE-MIT) and
[`LICENSE-APACHE`](./LICENSE-APACHE).
